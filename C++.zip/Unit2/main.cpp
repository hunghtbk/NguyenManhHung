#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <string>
using namespace std;

class firstClass{
public:
    vector<string> m_listName;
    firstClass(){}
    ~firstClass(){}
    void addName(string name){
        m_listName.push_back(name);
    }

    void removeName(string name){
        int j = -1;
        for(unsigned int i = 0; i < m_listName.size();i++)
        {
            if(m_listName.at(i)== name)
               j = i;
        }
        if(j >= 0)
        m_listName.erase(m_listName.begin()+j);
        else
        cout<< "Not found " <<name<<" in vector "<< endl;
    }

    void sortName(){
        sort(m_listName.begin(),m_listName.end());
    }

    void writeName(){
        ofstream ofs;
        ofs.open("listname.txt", std::ofstream::out);
        for(unsigned int i = 0; i < m_listName.size();i++)
        {
            ofs << m_listName.at(i) << endl;
        }
        ofs.close();
    }

    void readName(){
        string line;
        ifstream ifs ("listname.txt");
        cout << "-------------------" << endl;
        if (ifs.is_open())
        {
            while( getline(ifs,line))
            {
                cout << line << endl;
            }
            ifs.close();
        }

        else cout << "Unable to open file";

    }
};

class secondClass{
public:
    secondClass(){}
    ~secondClass(){}
    firstClass object;
    void getStringName(){
        string in;
        cout<<"Enter name ... "<<endl;

        for(;;){
            cin>>in;
            if(in!="exit")
                object.addName(in);
            else
            break;
        }
    }

    void sortName(){
        object.sortName();
    }

    void writeName(){
        object.writeName();
    }

    void readName(){
        object.readName();
    }

    void removeName(){
        string in;
        cout << "Remove name: " <<endl;
        cin >> in;
        object.removeName(in);
    }


};

int main()
{
    secondClass temp;
    temp.getStringName();
    temp.sortName();
    temp.writeName();
    temp.readName();
    temp.removeName();
    temp.writeName();
    temp.readName();

    return 0;
}
