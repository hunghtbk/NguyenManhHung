#include "rectangular.h"

Rectangular::Rectangular(int a, int b):Shape(a){ width = b;}

Rectangular::~Rectangular(){}

int Rectangular::getPerimeter(){
    return (height+width)*2;
}

int Rectangular::getArea(){
    return height*width;
}
