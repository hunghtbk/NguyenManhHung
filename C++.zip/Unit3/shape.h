#ifndef SHAPE_H
#define SHAPE_H
class Shape{
protected:
    int height;
public:
    Shape(int a);
    ~Shape();
    virtual int getPerimeter() = 0;
    virtual int getArea() = 0;
};
#endif // SHAPE_H
