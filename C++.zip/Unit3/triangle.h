#ifndef TRIANGLE_H
#define TRIANGLE_H
#include "shape.h"

class Triangle:public Shape
{
public:
    Triangle(int a,int b);
    ~Triangle();
protected:
    int width;
};

#endif // TRIANGLE_H
