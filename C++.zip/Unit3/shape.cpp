#include "shape.h"

Shape::Shape(int a = 0){height = a;}

Shape::~Shape(){}



