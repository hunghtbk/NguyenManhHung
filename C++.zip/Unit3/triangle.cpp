#include "triangle.h"
#include <cmath>

Triangle::Triangle(int a,int b):Shape(a){ width = b;}

Triangle::~Triangle(){}

int Triangle::getPerimeter(){
    return 2*sqrt(pow(height,2)+pow(width,2)/4) +width;
}

int Triangle::getArea(){
    return (height*width)/2;
}
