#ifndef RECTANGULAR_H
#define RECTANGULAR_H
#include "shape.h"

class Rectangular:public Shape
{
protected:
    int width;
public:
    Rectangular(int a, int b);
    ~Rectangular();
};

#endif // RECTANGULAR_H
