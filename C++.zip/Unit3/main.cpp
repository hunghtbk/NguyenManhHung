#include <iostream>
#include "shape.h"
#include "triangle.h"
#include "rectangular.h"
#include "square.h"

using namespace std;
/*
class Shape{
protected:
    int height;
public:
    Shape(int a = 0):height(a){}
    ~Shape(){}
    virtual int getPerimeter() = 0;
    virtual int getArea() = 0;
};

class Rectangular:public Shape{
protected:
    int width;
public:
    Rectangular(int a = 0, int b = 0):Shape(a){ width = b;}
    ~Rectangular(){}
    int getPerimeter(){
        return (height+width)*2;
    }
    int getArea(){
        return height*width;
    }
};

class Triangle:public Shape{
protected:
    int width;
public:
    Triangle(int a = 0,int b = 0):Shape(a){ width = b;}
    ~Triangle(){}
    int getPerimeter(){
        return 2*sqrt(pow(height,2)+pow(width,2)/4) +width;
    }
    int getArea(){
        return (height*width)/2;
    }
};

class Square:public Shape{
public:
    Square(int a = 0):Shape(a){}
    ~Square(){}
    int getPerimeter(){
        return 4*height;
    }
    int getArea(){
        return height*height;
    }
};
*/
int main()
{
    Rectangular rect(3,4);
    Triangle tria(4,6);
    Square squa(5);
    Shape *shape;
    shape = &rect;
    cout<<"Dien tich hcn:"<<shape->getArea()<<endl;
    cout<<"Chu vi hcn:"<<shape->getPerimeter()<<endl;
    shape = &tria;
    cout<<"Dien tich tg:"<<shape->getArea()<<endl;
    cout<<"Chu vi tg:"<<shape->getPerimeter()<<endl;
    shape = &squa;
    cout<<"Dien tich v:"<<shape->getArea()<<endl;
    cout<<"Chu vi v:"<<shape->getPerimeter()<<endl;
    return 0;
}
