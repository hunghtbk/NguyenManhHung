#include "square.h"

Square::Square(int a):Shape(a){}

Square::~Square(){}

int Square::getPerimeter(){
    return 4*height;
}

int Square::getArea(){
    return height*height;
}
