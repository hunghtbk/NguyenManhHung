#include <iostream>

using namespace std;

class Mat{
public:
    int row;
    int col;
    int array[50][50];
    Mat(){}
    ~Mat(){}
    void print();
    friend Mat operator + (Mat const &mat1, Mat const &mat2);
    friend Mat operator - (Mat const &mat1, Mat const &mat2);
    friend Mat operator * (Mat const &mat1, Mat const &mat2);
    friend ostream &operator << (ostream &out, Mat &mat);
    friend istream &operator >> (istream &in, Mat &mat);
};

void Mat::print(){
    cout<<"----------------------------"<<endl;
    for(int i = 0;i < row;i++){
        for(int j = 0;j < col;j++){
            cout<< array[i][j] << endl;
        }
    }
}

ostream &operator << (ostream &out, Mat &mat)
{

    for (int i = 0; i < mat.row; i++)
    {
        for (int j = 0; j < mat.col; j++)
        {
            out << mat.array[i][j] << "\t";
            if (j == mat.col - 1)
                out << endl;
        }
    }
    return out;
}

istream &operator >> (istream &in, Mat &mat)
{
    for (int i = 0; i < mat.row; i++)
    {
        for (int j = 0; j < mat.col; j++)
        {
            cout << "Enter value in row " << i<< " and column " << j<< ": ";
            in >> mat.array[i][j];
        }
    }
    return in;
}

Mat operator + (Mat const &mat1, Mat const &mat2){
    Mat res;
if(mat1.row==mat2.row && mat1.col==mat2.col){
    res.row = mat2.row;
    res.col = mat2.col;
    for(int i = 0;i < mat2.row;i++){
        for(int j = 0;j < mat2.col;j++){
           res.array[i][j] = mat1.array[i][j]+mat2.array[i][j];
        }
    }
}
else
    cout<<"Two matrix must same size..."<<endl;
return res;
}

Mat operator - (Mat const &mat1, Mat const &mat2){
Mat res;
if(mat1.row==mat2.row && mat1.col==mat2.col){
    res.row = mat2.row;
    res.col = mat2.col;
for(int i = 0;i < mat2.row;i++){
    for(int j = 0;j < mat2.col;j++){
        res.array[i][j] = mat1.array[i][j]-mat2.array[i][j];
    }
}
}
else
    cout<<"Two matrix must same size..."<<endl;
return res;
}

Mat operator * (Mat const &mat1, Mat const &mat2){
Mat res;
if(mat1.row==mat2.row && mat1.col==mat2.col){
    res.row = mat2.row;
    res.col = mat2.col;
for(int i = 0;i < mat2.row;i++){
    for(int j = 0;j < mat2.col;j++){
        res.array[i][j] = mat1.array[i][j]*mat2.array[i][j];
    }
}
}
else
    cout<<"Two matrix must same size..."<<endl;
return res;
}



int main()
{
    Mat mat1,mat2;
        mat1.row = 4;
        mat1.col = 4;
        mat2.row = 4;
        mat2.col = 4;

    cin >> mat1;
    cin >> mat2;

    Mat mat3 = mat1 + mat2;
    cout<<mat3<<endl;

    Mat mat4 = mat1 - mat2;
    cout<<mat4<<endl;


    Mat mat5 = mat1 * mat2;
    cout<<mat5<<endl;

    return 0;
}
