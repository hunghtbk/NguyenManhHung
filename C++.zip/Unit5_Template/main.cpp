#include <iostream>
#include <string>

using namespace std;

template <class T>
class TemplateSample
{
public:
    TemplateSample() {}
    ~TemplateSample() {delete[] data;}

    void push(T item){
        T *temp = new T[++m_size];
        for(int i = 0; i < (m_size-1); i++){
            temp[i] = data[i];
        }
        temp[m_size - 1] = item;
        data = new T[m_size];
        data = temp;
        //m_size++;
        delete temp;
    }

    int size(){
        return m_size;
    }

    void remove(T index){
        T *temp = new T[--m_size];
        for(int i = 0;i < index; i++)
        {
            temp[i] = data[i];
        }
        for(int i = index; i < (m_size);i++)
        {
            temp[i] = data[i+1];
        }
        delete[] data;
        data = temp;
       // m_size--;
        delete temp;
    }

    T at(int index){
        return data[index];
    }

    void empty(){
        delete data;
        m_size = 0;
    }

private:
    T *data;
    int m_size = 0;
};

class Person{
public:
    Person(){}
    ~Person(){}
    string m_name;
    int m_age;
};

int main()
{
    TemplateSample<int> tempObject0;
    tempObject0.push(3);
    tempObject0.push(4);
    tempObject0.push(5);
    cout<<"Size of templateObject0:" <<tempObject0.size()<<endl;

    TemplateSample<float> tempObject;
    tempObject.push(2.1);
    tempObject.push(2.3);
    cout<<"Size of templateObject:" <<tempObject.size()<<endl;
    tempObject.remove(0);
    cout<<"Size of templateObject after remove(0):" <<tempObject.size()<<endl;

    Person One;
    One.m_age = 12;
    One.m_name = "Fuc";
    TemplateSample<Person> tempObject1;

    tempObject1.push(One);
    //cout<<tempObject1.data[0].m_age<<endl;


    cout<<"Name: " <<tempObject1.at(0).m_name<<endl;
    cout<<"Age: " <<tempObject1.at(0).m_age<<endl;

    cout<<"Size of templateObject1 before empty():" <<tempObject1.size()<<endl;
    tempObject1.empty();
    cout<<"Size of templateObject1 after empty():" <<tempObject1.size()<<endl;

}
