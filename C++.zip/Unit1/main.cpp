#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

void getString(){
    string in;
    std::ofstream ofs;
    cout<<"Please fill string ... "<<endl;
    getline(cin, in);
    while(in.empty()){
        cout<<"string empty. please fill again..."<<endl;
        cin>>in;
    }
    ofs.open ("test.txt", std::ofstream::out);
    ofs << in <<endl;
    ofs.close();
}

void writeStrig(){
    string out;
    std::ifstream ifs;
    ifs.open("test.txt", std::ifstream::in);
    getline(ifs,out);
    cout<< out << endl;
    ifs.close();
}

int main()
{
    getString();
    writeStrig();
}
