#include <iostream>
#include <string>
#include <vector>

using namespace std;
class Student{
public:
    string m_name;
    string m_id;
    int m_age;
    Student(){}
    Student(string name, string id, int age):m_name(name),m_id(id),m_age(age){}
    ~Student(){}

    void setName(string name){
        m_name = name;
    }

    void setId(string id){
        m_id = id;
    }

    void setAge(int age){
        m_age = age;
    }
};

class Manager{
public:
    Manager(){}
    ~Manager(){}
    vector<Student> list;

    void add(Student std){
        list.push_back(std);
    }

    void edid(int index){
        string nameTemp;
        int ageTemp;

        if(((list.size()-1))< index  || (index < 0))
        cout<< "Error index" <<endl;

        cout<< "Enter Name: " <<endl;
        cin >> nameTemp;
        cout<< "Enter Age: " <<endl;
        cin >> ageTemp;
        list[index].setName(nameTemp);
        list[index].setAge(ageTemp);
    }

    void remove(int index){
        if(((list.size()-1)< index) || (index < 0))
        cout<< "Error index" <<endl;

        list.erase(list.begin()+index);
    }

};

int main()
{
    Student A,B,C;
    A.setName("Hung");
    A.setId("111");
    A.setAge(23);

    B.setName("Nam");
    B.setId("222");
    B.setAge(32);

    C.setName("Hai");
    C.setId("333");
    C.setAge(42);

    Manager manager;
    manager.add(A);
    manager.add(B);
    manager.add(C);

    for(unsigned int i =0; i < manager.list.size();i++){
        cout<<manager.list.at(i).m_name<<"  "<<manager.list.at(i).m_age<<endl;
    }

    manager.edid(1);
    manager.remove(2);

    for(unsigned int i =0; i < manager.list.size();i++){
        cout<<manager.list.at(i).m_name<<"  "<<manager.list.at(i).m_age<<endl;
    }
}
